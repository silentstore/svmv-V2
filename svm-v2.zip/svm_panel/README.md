# SVM Panel — VPS Management Panel
**Developer: AKShadowXff**  
**Version: 6.0-PRO-ULTIMATE**

A full-featured web-based LXC Container / VPS Management System built with Flask.

---

## 🚀 Quick Start

```bash
# 1. Clone / extract
cd svm_panel

# 2. Configure
cp .env.example .env
nano .env   # Edit SECRET_KEY, admin credentials, server IP

# 3. Install dependencies
pip3 install -r requirements.txt

# 4. Start
./start.sh
# or
python3 svm.py
```

Open your browser at `http://your-server-ip:5000`

---

## ✨ Features

### VPS Management
- Create, start, stop, restart, suspend, delete VPS/LXC containers
- Web-based SSH console with copy-paste support
- File manager per VPS
- VPS reinstall with OS selection
- Port forwarding management
- Bandwidth quota monitoring
- VPS snapshots & backups
- SSH key management

### Operating Systems Supported
Ubuntu 20/22/24 · Debian 10/11/12/13 · CentOS Stream 9 · Rocky Linux 8/9 · AlmaLinux 8/9 · Alpine 3.18/3.19/3.20 · Fedora 39/40 · Arch Linux · openSUSE · Kali Linux

### User Features
- Support ticket system
- SSH key management
- Personal activity log
- Dark/Light theme toggle
- Notification system
- 2FA (Google Authenticator / Authy)

### Admin Features
- Multi-node cluster management
- Node health overview
- Bulk VPS actions (start/stop/suspend/delete)
- VPS Plans/Templates system
- Announcement system (broadcast to all users)
- User management (create, edit, delete, suspend)
- Expiring VPS tracker
- Activity logs
- SMTP email configuration
- Background image/video upload
- Background sound support
- Discord OAuth integration

### Security
- Brute force protection (5 attempts → 5 min lockout)
- Real TOTP 2FA validation (pyotp)
- CSRF protection
- Rate limiting
- SSH key authentication support
- Secure password generation (24+ chars, mixed)

---

## ⚙️ Configuration (.env)

| Variable | Default | Description |
|---|---|---|
| `SECRET_KEY` | **REQUIRED** | Random secret for sessions |
| `DATABASE_PATH` | `svm.db` | SQLite DB path |
| `HOST` | `0.0.0.0` | Bind address |
| `PORT` | `5000` | Listen port |
| `MAIN_ADMIN_USERNAME` | `admin` | Admin username |
| `MAIN_ADMIN_PASSWORD` | `admin` | Admin password (CHANGE THIS!) |
| `YOUR_SERVER_IP` | auto | Your server's public IP |

---

## 📁 File Structure

```
svm_panel/
├── svm.py              # Main application
├── api.py              # REST API blueprint
├── requirements.txt    # Python dependencies
├── .env.example        # Config template
├── start.sh            # Startup script
├── templates/          # Jinja2 HTML templates
│   ├── base.html       # Layout with sidebar/header
│   ├── admin/          # Admin panel templates
│   └── ...
├── static/             # Static files
│   └── uploads/        # Uploaded media
└── backups/            # Database backups
```

---

## 🔒 Security Hardening (Production)

1. Set a strong `SECRET_KEY` (min 32 chars random)
2. Change default admin password immediately
3. Run behind Nginx with SSL
4. Enable 2FA for admin accounts
5. Restrict panel port via firewall

---

© 2024 AKShadowXff — All Rights Reserved
