#!/bin/bash
# SVM Panel Startup Script
echo "=============================="
echo "  SVM Panel - AKShadowXff"
echo "=============================="

# Check if .env exists
if [ ! -f .env ]; then
    echo "WARNING: .env file not found! Copying .env.example..."
    cp .env.example .env
    echo "Please edit .env with your real settings before running in production!"
fi

# Install requirements if needed
if ! python3 -c "import flask" 2>/dev/null; then
    echo "Installing dependencies..."
    pip3 install -r requirements.txt
fi

# Create required directories
mkdir -p static/uploads/settings
mkdir -p static/uploads/backgrounds
mkdir -p backups
mkdir -p logs

echo "Starting SVM Panel..."
python3 svm.py
